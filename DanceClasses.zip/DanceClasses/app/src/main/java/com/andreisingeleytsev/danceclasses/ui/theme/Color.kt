package com.andreisingeleytsev.danceclasses.ui.theme

import androidx.compose.ui.graphics.Color

val Primary = Color(0xFFEF3461)
val BackgroundColor = Color(0xFFFAFAFA)
