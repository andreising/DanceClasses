package com.andreisingeleytsev.danceclasses.ui.utils

object DanceConverter {
    val list = mapOf(
        1 to DanceItem.Bachata,
        2 to DanceItem.HipHop,
        3 to DanceItem.Rumba,
        4 to DanceItem.Salsa,
        5 to DanceItem.Tango,
        6 to DanceItem.Zumba,
    )
}