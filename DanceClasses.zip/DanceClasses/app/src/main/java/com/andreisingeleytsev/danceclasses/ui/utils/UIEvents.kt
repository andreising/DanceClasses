package com.andreisingeleytsev.danceclasses.ui.utils

sealed class UIEvents(){
    object Roll: UIEvents()
}