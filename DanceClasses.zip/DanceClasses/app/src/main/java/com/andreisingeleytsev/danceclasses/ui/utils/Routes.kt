package com.andreisingeleytsev.danceclasses.ui.utils

object Routes {
    const val HOME_SCREEN = "home_screen"
    const val MAIN_SCREEN = "main_screen"
    const val ONBOARD_SCREEN = "onboard_screen"
    const val CALENDAR_SCREEN = "calendar_screen"
    const val DETAILS_SCREEN = "details_screen"
}